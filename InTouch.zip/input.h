#ifndef __INPUT_H__
#define __INPUT_H__

// Namespace
using namespace std;

int inputInt(int min, int max);
string inputString(int max);
string inputEmail(int max);
string inputPassword(int max);

#endif

